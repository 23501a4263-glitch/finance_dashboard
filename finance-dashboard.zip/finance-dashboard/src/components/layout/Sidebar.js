import React from 'react';
import { useApp } from '../../context/AppContext';

const NAV_ITEMS = [
  { id: 'dashboard',    icon: '📊', label: 'Dashboard'    },
  { id: 'transactions', icon: '📄', label: 'Transactions'  },
  { id: 'insights',     icon: '🧠', label: 'Insights'      },
];

export default function Sidebar({ onClose }) {
  const { state, dispatch } = useApp();

  const setTab = (id) => {
    dispatch({ type: 'SET_TAB', payload: id });
    if (onClose) onClose();
  };

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-icon">💰</div>
        FinanceFlow
      </div>

      <nav style={{ flex: 1 }}>
        {NAV_ITEMS.map(item => (
          <div
            key={item.id}
            className={`nav-item${state.activeTab === item.id ? ' active' : ''}`}
            onClick={() => setTab(item.id)}
          >
            <span style={{ fontSize: 18 }}>{item.icon}</span>
            {item.label}
          </div>
        ))}
      </nav>

      <div className="sidebar-footer">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
          <div style={{
            width: 36, height: 36, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 13, fontWeight: 700, color: '#0a0e1a', flexShrink: 0,
          }}>
            {state.user?.avatar}
          </div>
          <div style={{ overflow: 'hidden' }}>
            <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-1)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {state.user?.name}
            </p>
            <p style={{ fontSize: 11, color: 'var(--text-3)' }}>
              {state.role === 'admin' ? '🔐 Admin' : '👁️ Viewer'}
            </p>
          </div>
        </div>
        <button
          className="btn btn-ghost"
          style={{ width: '100%', justifyContent: 'center', fontSize: 13 }}
          onClick={() => dispatch({ type: 'LOGOUT' })}
        >
          ← Logout
        </button>
      </div>
    </aside>
  );
}
