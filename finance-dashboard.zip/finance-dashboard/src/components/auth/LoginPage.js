import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';

export default function AuthPage() {
  const { login, signup, authError, setAuthError } = useApp();
  const [mode, setMode]     = useState('login'); // 'login' | 'signup'
  const [role, setRole]     = useState('viewer');
  const [name, setName]     = useState('');
  const [email, setEmail]   = useState('');
  const [password, setPwd]  = useState('');
  const [confirm, setConf]  = useState('');
  const [loading, setLoad]  = useState(false);
  const [showPwd, setShowP] = useState(false);
  const [localErr, setLE]   = useState('');

  const switchMode = (m) => { setMode(m); setAuthError(''); setLE(''); setName(''); setEmail(''); setPwd(''); setConf(''); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLE('');
    if (mode === 'signup' && password !== confirm) { setLE('Passwords do not match.'); return; }
    if (mode === 'signup' && password.length < 6)  { setLE('Password must be at least 6 characters.'); return; }
    setLoad(true);
    await new Promise(r => setTimeout(r, 600));
    if (mode === 'login')  login(email, password);
    else                   signup(name.trim(), email, password, role);
    setLoad(false);
  };

  const err = localErr || authError;

  return (
    <div className="login-page">
      <div className="card login-card">
        {/* Logo */}
        <div className="login-logo">
          <div className="logo-big">💰</div>
          <h1>FinanceFlow</h1>
          <p>{mode === 'login' ? 'Sign in to your account' : 'Create your account'}</p>
        </div>

        {/* Tab switcher */}
        <div style={{ display:'flex', background:'var(--bg-card2)', borderRadius:'var(--radius-sm)', padding:4, marginBottom:24, border:'1px solid var(--border)' }}>
          {['login','signup'].map(m => (
            <button key={m} onClick={() => switchMode(m)}
              style={{ flex:1, padding:'8px 0', border:'none', borderRadius:6, cursor:'pointer', fontSize:14, fontWeight:500, fontFamily:'var(--font-body)',
                background: mode===m ? 'var(--accent)' : 'transparent',
                color:      mode===m ? '#0a0e1a'        : 'var(--text-2)',
                transition: 'all 0.2s' }}>
              {m === 'login' ? '🔑 Sign In' : '✨ Sign Up'}
            </button>
          ))}
        </div>

        {/* Role picker — signup only */}
        {mode === 'signup' && (
          <>
            <p style={{ fontSize:12, color:'var(--text-3)', marginBottom:10, textAlign:'center' }}>Choose your role</p>
            <div className="role-selector" style={{ marginBottom:16 }}>
              {[{key:'admin',icon:'🔐',name:'Admin',desc:'Full access'},{key:'viewer',icon:'👁️',name:'Viewer',desc:'Read only'}].map(r => (
                <div key={r.key} className={`role-option${role===r.key?' selected':''}`} onClick={() => setRole(r.key)}>
                  <div className="role-icon">{r.icon}</div>
                  <div className="role-name">{r.name}</div>
                  <div className="role-desc">{r.desc}</div>
                </div>
              ))}
            </div>
          </>
        )}

        <form onSubmit={handleSubmit}>
          {mode === 'signup' && (
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input className="input" placeholder="Your full name" value={name} onChange={e=>setName(e.target.value)} required />
            </div>
          )}
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} required />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <div style={{ position:'relative' }}>
              <input className="input" type={showPwd?'text':'password'}
                placeholder={mode==='login'?'Enter your password':'Min 6 characters'}
                value={password} onChange={e=>setPwd(e.target.value)} required style={{ paddingRight:42 }} />
              <span onClick={() => setShowP(!showPwd)}
                style={{ position:'absolute', right:12, top:'50%', transform:'translateY(-50%)', cursor:'pointer', fontSize:16, userSelect:'none' }}>
                {showPwd ? '🙈' : '👁️'}
              </span>
            </div>
          </div>
          {mode === 'signup' && (
            <div className="form-group">
              <label className="form-label">Confirm Password</label>
              <input className="input" type={showPwd?'text':'password'} placeholder="Repeat password" value={confirm} onChange={e=>setConf(e.target.value)} required />
            </div>
          )}

          {err && <p style={{ color:'var(--accent3)', fontSize:13, marginBottom:12, textAlign:'center', background:'rgba(244,114,182,0.08)', padding:'8px 12px', borderRadius:8 }}>{err}</p>}

          <button className="btn btn-primary" type="submit"
            style={{ width:'100%', justifyContent:'center', padding:'12px', fontSize:15, marginTop:4 }} disabled={loading}>
            {loading ? '⏳ Please wait...' : mode === 'login' ? '→ Sign In' : '✨ Create Account'}
          </button>
        </form>

        {/* Demo shortcuts */}
        <div style={{ marginTop:20, paddingTop:16, borderTop:'1px solid var(--border)' }}>
          <p style={{ fontSize:12, color:'var(--text-3)', textAlign:'center', marginBottom:10 }}>Quick demo login</p>
          <div style={{ display:'flex', gap:8 }}>
            <button className="btn btn-ghost" style={{ flex:1, justifyContent:'center', fontSize:12 }}
              onClick={() => { setMode('login'); setEmail('admin@financeflow.io'); setPwd('admin123'); }}>
              🔐 Admin
            </button>
            <button className="btn btn-ghost" style={{ flex:1, justifyContent:'center', fontSize:12 }}
              onClick={() => { setMode('login'); setEmail('viewer@financeflow.io'); setPwd('viewer123'); }}>
              👁️ Viewer
            </button>
          </div>
          <p style={{ fontSize:11, color:'var(--text-3)', textAlign:'center', marginTop:8 }}>
            Click a demo button then hit Sign In
          </p>
        </div>
      </div>
    </div>
  );
}
