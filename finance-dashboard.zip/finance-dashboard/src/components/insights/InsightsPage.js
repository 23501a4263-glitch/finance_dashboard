import React from 'react';
import { getCategoryData, getMonthlyData, fmt } from '../../data/mockData';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

const BarTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: 'var(--bg-card2)', border: '1px solid var(--border)', borderRadius: 8, padding: '8px 12px', fontSize: 13 }}>
      <p style={{ color: 'var(--text-2)' }}>{label}</p>
      {payload.map((p, i) => <p key={i} style={{ color: p.color }}>{p.name}: {fmt(p.value)}</p>)}
    </div>
  );
};

export default function InsightsPage({ transactions }) {
  const catData   = getCategoryData(transactions);
  const monthly   = getMonthlyData(transactions);
  const income    = transactions.filter(t => t.type === 'income').reduce((s,t) => s + t.amount, 0);
  const expenses  = transactions.filter(t => t.type === 'expense').reduce((s,t) => s + t.amount, 0);
  const balance   = income - expenses;
  const savingsR  = income > 0 ? Math.round(balance / income * 100) : 0;
  const topCat    = catData[0];
  const topSpend  = topCat ? Math.round(topCat.value / expenses * 100) : 0;

  const lastTwo = monthly.slice(-2);
  const prevMonth  = lastTwo[0];
  const curMonth   = lastTwo[1];
  const monthDelta = prevMonth && curMonth ? curMonth.expenses - prevMonth.expenses : 0;

  const avgTxAmount = transactions.length ? Math.round(expenses / transactions.filter(t => t.type === 'expense').length) : 0;

  const insights = [
    {
      icon: '🔥',
      label: 'Top Spending Category',
      value: topCat ? `${topCat.icon} ${topCat.name}` : 'N/A',
      sub: topCat ? `${fmt(topCat.value)} — ${topSpend}% of total expenses` : '',
      color: '#f472b6',
    },
    {
      icon: '💰',
      label: 'Net Savings',
      value: fmt(balance),
      sub: `${savingsR}% savings rate ${savingsR > 20 ? '🎉 Great job!' : '📌 Aim for 20%+'}`,
      color: balance > 0 ? '#6ee7b7' : '#f472b6',
    },
    {
      icon: '📅',
      label: 'Monthly Expense Change',
      value: monthDelta > 0 ? `+${fmt(monthDelta)}` : fmt(monthDelta),
      sub: prevMonth ? `vs ${prevMonth.name}` : 'Not enough data',
      color: monthDelta > 0 ? '#f472b6' : '#6ee7b7',
    },
    {
      icon: '🧾',
      label: 'Avg Transaction',
      value: fmt(avgTxAmount),
      sub: `across ${transactions.filter(t => t.type === 'expense').length} expense transactions`,
      color: '#818cf8',
    },
    {
      icon: '📊',
      label: 'Income vs Expenses',
      value: `${income > 0 ? Math.round(expenses/income*100) : 0}% spent`,
      sub: `${fmt(income)} earned · ${fmt(expenses)} spent`,
      color: '#fbbf24',
    },
    {
      icon: '🎯',
      label: 'Financial Health',
      value: savingsR > 30 ? 'Excellent' : savingsR > 15 ? 'Good' : savingsR > 0 ? 'Fair' : 'Needs Work',
      sub: `Based on savings rate of ${savingsR}%`,
      color: savingsR > 30 ? '#6ee7b7' : savingsR > 15 ? '#fbbf24' : '#f472b6',
    },
  ];

  return (
    <div className="fade-in">
      <div className="topbar">
        <div>
          <div className="topbar-title">🧠 Insights</div>
          <p style={{ color: 'var(--text-2)', fontSize: 13 }}>Smart observations from your data</p>
        </div>
      </div>

      <div className="insights-grid fade-in-delay-1" style={{ marginBottom: 24 }}>
        {insights.map((ins, i) => (
          <div key={i} className="card insight-card" style={{ borderLeft: `3px solid ${ins.color}` }}>
            <div className="insight-icon">{ins.icon}</div>
            <div className="insight-label">{ins.label}</div>
            <div className="insight-value" style={{ color: ins.color }}>{ins.value}</div>
            <div className="insight-sub">{ins.sub}</div>
          </div>
        ))}
      </div>

      {/* Category breakdown bar */}
      <div className="card chart-card fade-in-delay-2" style={{ marginBottom: 20 }}>
        <div className="chart-title">📊 Spending by Category</div>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={catData} layout="vertical" margin={{ top: 0, right: 20, bottom: 0, left: 10 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
            <XAxis type="number" tick={{ fill: '#475569', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => '₹' + (v/1000).toFixed(0) + 'k'} />
            <YAxis type="category" dataKey="name" tick={{ fill: '#94a3b8', fontSize: 12 }} axisLine={false} tickLine={false} width={90} tickFormatter={(v) => (catData.find(c => c.name === v)?.icon || '') + ' ' + v} />
            <Tooltip content={<BarTooltip />} />
            <Bar dataKey="value" name="Amount" radius={[0, 4, 4, 0]}>
              {catData.map((entry, i) => (
                <rect key={i} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Monthly comparison */}
      <div className="card chart-card fade-in-delay-3">
        <div className="chart-title">📅 Monthly Comparison</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={monthly} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="name" tick={{ fill: '#475569', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#475569', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => '₹' + (v/1000).toFixed(0) + 'k'} />
            <Tooltip content={<BarTooltip />} />
            <Bar dataKey="income"   name="Income"   fill="#6ee7b7" radius={[4,4,0,0]} />
            <Bar dataKey="expenses" name="Expenses" fill="#f472b6" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
