import React from 'react';
import { fmt } from '../../data/mockData';

export default function SummaryCards({ transactions }) {
  const income   = transactions.filter(t => t.type === 'income' ).reduce((s,t) => s + t.amount, 0);
  const expenses = transactions.filter(t => t.type === 'expense').reduce((s,t) => s + t.amount, 0);
  const balance  = income - expenses;
  const savings  = income > 0 ? Math.round((balance / income) * 100) : 0;

  const cards = [
    { cls: 'card-balance',  icon: '💰', label: 'Total Balance',  value: fmt(balance),  change: `${savings}% savings rate`, up: savings > 0 },
    { cls: 'card-income',   icon: '📈', label: 'Total Income',   value: fmt(income),   change: '+12% vs last month', up: true },
    { cls: 'card-expense',  icon: '📉', label: 'Total Expenses', value: fmt(expenses), change: '+5% vs last month',  up: false },
    { cls: 'card-savings',  icon: '🏦', label: 'Savings Rate',   value: `${savings}%`, change: 'of total income', up: savings > 20 },
  ];

  return (
    <div className="summary-grid">
      {cards.map((c, i) => (
        <div key={i} className={`card summary-card ${c.cls} fade-in-delay-${i}`}>
          <div className="card-icon">{c.icon}</div>
          <div className="card-label">{c.label}</div>
          <div className="card-value">{c.value}</div>
          <div className="card-change" style={{ color: c.up ? 'var(--accent)' : 'var(--accent3)' }}>
            {c.up ? '↑' : '↓'} {c.change}
          </div>
        </div>
      ))}
    </div>
  );
}
