import React from 'react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { getMonthlyData, getCategoryData, fmt } from '../../data/mockData';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{
      background: 'var(--bg-card2)', border: '1px solid var(--border)',
      borderRadius: 8, padding: '10px 14px', fontSize: 13,
    }}>
      <p style={{ color: 'var(--text-2)', marginBottom: 6 }}>{label}</p>
      {payload.map((p, i) => (
        <p key={i} style={{ color: p.color }}>
          {p.name}: {fmt(p.value)}
        </p>
      ))}
    </div>
  );
};

const PieTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const d = payload[0];
  return (
    <div style={{
      background: 'var(--bg-card2)', border: '1px solid var(--border)',
      borderRadius: 8, padding: '8px 12px', fontSize: 13,
    }}>
      <p style={{ color: d.payload.color }}>{d.payload.icon} {d.name}</p>
      <p style={{ color: 'var(--text-1)' }}>{fmt(d.value)}</p>
    </div>
  );
};

export default function Charts({ transactions }) {
  const monthly  = getMonthlyData(transactions);
  const catData  = getCategoryData(transactions).slice(0, 6);

  return (
    <div className="charts-grid fade-in-delay-2">
      {/* Area Chart */}
      <div className="card chart-card">
        <div className="chart-title">💹 Income vs Expenses Trend</div>
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={monthly} margin={{ top: 5, right: 5, bottom: 0, left: 0 }}>
            <defs>
              <linearGradient id="incomeGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#6ee7b7" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#6ee7b7" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="expenseGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor="#f472b6" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#f472b6" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
            <XAxis dataKey="name" tick={{ fill: '#475569', fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: '#475569', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => '₹' + (v/1000).toFixed(0) + 'k'} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="income"   name="Income"   stroke="#6ee7b7" strokeWidth={2} fill="url(#incomeGrad)" dot={{ fill: '#6ee7b7', r: 3 }} />
            <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#f472b6" strokeWidth={2} fill="url(#expenseGrad)" dot={{ fill: '#f472b6', r: 3 }} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Pie Chart */}
      <div className="card chart-card">
        <div className="chart-title">🍕 Spending Breakdown</div>
        <ResponsiveContainer width="100%" height={240}>
          <PieChart>
            <Pie
              data={catData} cx="50%" cy="50%"
              innerRadius={55} outerRadius={85}
              paddingAngle={3} dataKey="value"
            >
              {catData.map((entry, i) => (
                <Cell key={i} fill={entry.color} stroke="transparent" />
              ))}
            </Pie>
            <Tooltip content={<PieTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 14px', marginTop: 4 }}>
          {catData.map((c, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: 'var(--text-2)' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: c.color, display: 'inline-block' }} />
              {c.icon} {c.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
