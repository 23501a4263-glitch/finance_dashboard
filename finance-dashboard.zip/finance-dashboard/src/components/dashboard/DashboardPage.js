import React, { useState } from 'react';
import SummaryCards from './SummaryCards';
import Charts from './Charts';
import { useApp } from '../../context/AppContext';
import { fmt, CATEGORIES, INITIAL_TRANSACTIONS } from '../../data/mockData';
import TransactionModal from '../transactions/TransactionModal';

// ── Inline editable summary card ──────────────────────────────
function EditableCard({ card, isAdmin, onSave }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal]         = useState(card.editValue || '');

  if (!isAdmin || !card.editable) {
    return (
      <div className={`card summary-card ${card.cls} fade-in`}>
        <div className="card-icon">{card.icon}</div>
        <div className="card-label">{card.label}</div>
        <div className="card-value">{card.value}</div>
        <div className="card-change" style={{ color: card.up ? 'var(--accent)' : 'var(--accent3)' }}>
          {card.up ? '↑' : '↓'} {card.change}
        </div>
        <div style={{ fontSize:11, color:'var(--text-3)', marginTop:6 }}>🔒 View only</div>
      </div>
    );
  }

  return (
    <div className={`card summary-card ${card.cls} fade-in`} style={{ position:'relative' }}>
      {!editing && (
        <button onClick={() => { setEditing(true); setVal(card.editValue||''); }}
          style={{ position:'absolute', top:12, right:12, background:'rgba(110,231,183,0.12)', border:'1px solid rgba(110,231,183,0.25)',
            borderRadius:6, padding:'3px 8px', fontSize:11, color:'var(--accent)', cursor:'pointer', fontFamily:'var(--font-body)' }}>
          ✏️ Edit
        </button>
      )}
      <div className="card-icon">{card.icon}</div>
      <div className="card-label">{card.label}</div>
      {editing ? (
        <div>
          <input value={val} onChange={e=>setVal(e.target.value)} type="number"
            style={{ background:'transparent', border:'none', borderBottom:'2px solid var(--accent)', color:'inherit',
              fontSize:24, fontFamily:'var(--font-head)', fontWeight:700, width:'100%', outline:'none', marginBottom:8 }} />
          <div style={{ display:'flex', gap:6 }}>
            <button onClick={() => { onSave(card.key, val); setEditing(false); }}
              style={{ background:'var(--accent)', border:'none', borderRadius:6, padding:'4px 12px', fontSize:12,
                color:'#0a0e1a', cursor:'pointer', fontFamily:'var(--font-body)', fontWeight:600 }}>Save</button>
            <button onClick={() => setEditing(false)}
              style={{ background:'transparent', border:'1px solid var(--border)', borderRadius:6, padding:'4px 10px',
                fontSize:12, color:'var(--text-2)', cursor:'pointer', fontFamily:'var(--font-body)' }}>Cancel</button>
          </div>
        </div>
      ) : (
        <div className="card-value">{card.value}</div>
      )}
      <div className="card-change" style={{ color: card.up ? 'var(--accent)' : 'var(--accent3)' }}>
        {card.up ? '↑' : '↓'} {card.change}
      </div>
      {!editing && <div style={{ fontSize:11, color:'var(--accent)', marginTop:4 }}>🔐 Admin editable</div>}
    </div>
  );
}

// ── Dashboard ─────────────────────────────────────────────────
export default function DashboardPage() {
  const { state, dispatch } = useApp();
  const { transactions, role, user } = state;
  const isAdmin = role === 'admin';
  const recent  = transactions.slice(0, 6);
  const [showAdd, setShowAdd]  = useState(false);
  const [editTx, setEditTx]    = useState(null);
  const [goalIncome,  setGI]   = useState(() => parseInt(localStorage.getItem('ff_goalIncome')  || '150000'));
  const [goalSavings, setGS]   = useState(() => parseInt(localStorage.getItem('ff_goalSavings') || '30'));

  const income   = transactions.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0);
  const expenses = transactions.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0);
  const balance  = income - expenses;
  const savingsR = income>0 ? Math.round(balance/income*100) : 0;

  const cards = [
    { cls:'card-balance', icon:'💰', label:'Total Balance',  value:fmt(balance),  change:`${savingsR}% savings rate`, up:balance>0,  editable:false },
    { cls:'card-income',  icon:'📈', label:'Income Goal',    value:fmt(income),   change:`${Math.min(100,Math.round(income/goalIncome*100))}% of ₹${(goalIncome/1000).toFixed(0)}k goal`, up:income>=goalIncome, editable:true, key:'goalIncome',  editValue:goalIncome  },
    { cls:'card-expense', icon:'📉', label:'Total Expenses', value:fmt(expenses), change:'Tracked spending', up:false, editable:false },
    { cls:'card-savings', icon:'🏦', label:'Savings Target', value:`${savingsR}%`, change:`Goal: ${goalSavings}% ${savingsR>=goalSavings?'✅ Achieved!':'— keep going'}`, up:savingsR>=goalSavings, editable:true, key:'goalSavings', editValue:goalSavings },
  ];

  const handleCardSave = (key, val) => {
    if (key==='goalIncome')  { const v=parseInt(val)||150000; setGI(v); localStorage.setItem('ff_goalIncome', v);  }
    if (key==='goalSavings') { const v=parseInt(val)||30;     setGS(v); localStorage.setItem('ff_goalSavings', v); }
  };

  const resetData = () => { if(window.confirm('Reset all transactions to demo data?')) dispatch({ type:'EDIT_TRANSACTION', payload:{} }); };

  return (
    <div>
      {/* Header */}
      <div className="topbar fade-in">
        <div>
          <div className="topbar-title">👋 Welcome, {user?.name?.split(' ')[0]}!</div>
          <p style={{ color:'var(--text-2)', fontSize:13 }}>
            {isAdmin ? '🔐 Admin — you can edit goals, add & manage transactions' : '👁️ Viewer — read-only access to your financial data'}
          </p>
        </div>
        <div style={{ display:'flex', gap:8, alignItems:'center' }}>
          <span className={`badge badge-${role}`}>{role==='admin'?'🔐':'👁️'} {role}</span>
          {isAdmin && (
            <button className="btn btn-primary" style={{ fontSize:13 }} onClick={() => { setEditTx(null); setShowAdd(true); }}>
              + Add Transaction
            </button>
          )}
        </div>
      </div>

      {/* Role notice banner */}
      {!isAdmin && (
        <div style={{ background:'rgba(129,140,248,0.08)', border:'1px solid rgba(129,140,248,0.2)', borderRadius:'var(--radius-md)',
          padding:'12px 18px', marginBottom:20, display:'flex', alignItems:'center', gap:10, fontSize:13, color:'var(--accent2)' }}>
          👁️ <strong>Viewer Mode:</strong> You can view all financial data but cannot add, edit, or delete transactions. Contact an Admin for changes.
        </div>
      )}
      {isAdmin && (
        <div style={{ background:'rgba(110,231,183,0.06)', border:'1px solid rgba(110,231,183,0.18)', borderRadius:'var(--radius-md)',
          padding:'12px 18px', marginBottom:20, display:'flex', alignItems:'center', gap:10, fontSize:13, color:'var(--accent)' }}>
          🔐 <strong>Admin Mode:</strong> You have full access — click <strong>✏️ Edit</strong> on cards to update goals, and <strong>+ Add Transaction</strong> to log new entries.
        </div>
      )}

      {/* Summary cards (editable for admin) */}
      <div className="summary-grid" style={{ marginBottom:24 }}>
        {cards.map((c,i) => (
          <EditableCard key={i} card={c} isAdmin={isAdmin} onSave={handleCardSave} />
        ))}
      </div>

      <Charts transactions={transactions} />

      {/* Recent Transactions */}
      <div className="card fade-in-delay-3" style={{ padding:22, marginTop:4 }}>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
          <div className="chart-title" style={{ margin:0 }}>🕐 Recent Transactions</div>
          {isAdmin && (
            <button className="btn btn-ghost" style={{ fontSize:12 }} onClick={() => { setEditTx(null); setShowAdd(true); }}>
              + Add New
            </button>
          )}
        </div>
        {recent.length === 0 ? (
          <div className="empty-state"><div className="empty-icon">📭</div><p>No transactions yet</p></div>
        ) : (
          <div style={{ overflowX:'auto' }}>
            <table className="tx-table">
              <thead>
                <tr>
                  <th>Description</th><th>Date</th><th>Category</th><th>Amount</th>
                  {isAdmin && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {recent.map(t => {
                  const cat = CATEGORIES[t.category] || { icon:'📦', color:'#888' };
                  return (
                    <tr key={t.id}>
                      <td>
                        <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                          <div className="tx-cat-icon" style={{ background:cat.color+'22' }}>{cat.icon}</div>
                          <span style={{ color:'var(--text-1)', fontWeight:500 }}>{t.description}</span>
                        </div>
                      </td>
                      <td>{new Date(t.date).toLocaleDateString('en-IN',{day:'numeric',month:'short'})}</td>
                      <td style={{ color:cat.color, fontSize:13 }}>{cat.icon} {t.category}</td>
                      <td className={t.type==='income'?'amount-income':'amount-expense'}>
                        {t.type==='income'?'+':'-'}{fmt(t.amount)}
                      </td>
                      {isAdmin && (
                        <td>
                          <div style={{ display:'flex', gap:6 }}>
                            <button className="btn btn-ghost" style={{ padding:'4px 8px', fontSize:12 }}
                              onClick={() => { setEditTx(t); setShowAdd(true); }}>✏️</button>
                            <button className="btn btn-danger" style={{ padding:'4px 8px', fontSize:12 }}
                              onClick={() => { if(window.confirm('Delete this transaction?')) dispatch({ type:'DELETE_TRANSACTION', payload:t.id }); }}>🗑️</button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Admin-only: quick stats */}
      {isAdmin && (
        <div className="card fade-in" style={{ padding:20, marginTop:16, border:'1px solid rgba(110,231,183,0.15)' }}>
          <div className="chart-title">🔐 Admin Quick Actions</div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:10 }}>
            <button className="btn btn-primary" onClick={() => { setEditTx(null); setShowAdd(true); }}>➕ Add Transaction</button>
            <button className="btn btn-ghost" onClick={() => dispatch({ type:'SET_TAB', payload:'transactions' })}>📄 Manage All Transactions</button>
            <button className="btn btn-ghost" onClick={() => dispatch({ type:'SET_TAB', payload:'insights' })}>🧠 View Insights</button>
          </div>
        </div>
      )}

      {showAdd && <TransactionModal tx={editTx} onClose={() => setShowAdd(false)} />}
    </div>
  );
}
