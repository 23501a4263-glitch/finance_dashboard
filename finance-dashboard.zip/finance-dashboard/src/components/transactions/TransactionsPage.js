import React, { useState, useMemo } from 'react';
import { useApp } from '../../context/AppContext';
import { CATEGORIES, fmt } from '../../data/mockData';
import TransactionModal from './TransactionModal';

export default function TransactionsPage() {
  const { state, dispatch } = useApp();
  const { transactions, filters, role } = state;
  const isAdmin = role === 'admin';

  const [showModal, setShowModal] = useState(false);
  const [editTx, setEditTx] = useState(null);
  const [sortBy, setSortBy] = useState('date');
  const [sortDir, setSortDir] = useState('desc');
  const [deleteId, setDeleteId] = useState(null);

  const allCategories = [...new Set(transactions.map(t => t.category))];
  const allMonths = [...new Set(transactions.map(t => t.date.slice(0,7)))].sort().reverse();

  const filtered = useMemo(() => {
    let list = [...transactions];
    const { search, category, type, month } = filters;
    if (search)    list = list.filter(t => t.description.toLowerCase().includes(search.toLowerCase()) || t.category.toLowerCase().includes(search.toLowerCase()));
    if (category)  list = list.filter(t => t.category === category);
    if (type)      list = list.filter(t => t.type === type);
    if (month)     list = list.filter(t => t.date.startsWith(month));
    list.sort((a, b) => {
      let va = a[sortBy], vb = b[sortBy];
      if (sortBy === 'amount') { va = +va; vb = +vb; }
      if (va < vb) return sortDir === 'asc' ? -1 : 1;
      if (va > vb) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return list;
  }, [transactions, filters, sortBy, sortDir]);

  const toggleSort = (col) => {
    if (sortBy === col) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(col); setSortDir('desc'); }
  };

  const SortIcon = ({ col }) => {
    if (sortBy !== col) return <span style={{ color: 'var(--text-3)', marginLeft: 2 }}>⇅</span>;
    return <span style={{ color: 'var(--accent)', marginLeft: 2 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>;
  };

  const confirmDelete = (id) => { setDeleteId(id); };
  const doDelete = () => { dispatch({ type: 'DELETE_TRANSACTION', payload: deleteId }); setDeleteId(null); };

  const exportCSV = () => {
    const header = 'Date,Description,Category,Type,Amount\n';
    const rows = filtered.map(t => `${t.date},${t.description},${t.category},${t.type},${t.amount}`).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'transactions.csv'; a.click();
  };

  return (
    <div className="fade-in">
      {/* Topbar */}
      <div className="topbar">
        <div>
          <div className="topbar-title">📄 Transactions</div>
          <p style={{ color: 'var(--text-2)', fontSize: 13 }}>{filtered.length} records found</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-ghost" onClick={exportCSV} style={{ fontSize: 13 }}>⬇ CSV</button>
          {isAdmin && (
            <button className="btn btn-primary" onClick={() => { setEditTx(null); setShowModal(true); }}>
              + Add
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="card" style={{ padding: '16px 20px', marginBottom: 16 }}>
        <div className="filter-bar">
          <input
            className="input search-input"
            placeholder="🔍 Search transactions..."
            value={filters.search}
            onChange={e => dispatch({ type: 'SET_FILTER', payload: { search: e.target.value } })}
          />
          <select className="select" style={{ width: 140 }} value={filters.type} onChange={e => dispatch({ type: 'SET_FILTER', payload: { type: e.target.value } })}>
            <option value="">All Types</option>
            <option value="income">📈 Income</option>
            <option value="expense">📉 Expense</option>
          </select>
          <select className="select" style={{ width: 150 }} value={filters.category} onChange={e => dispatch({ type: 'SET_FILTER', payload: { category: e.target.value } })}>
            <option value="">All Categories</option>
            {allCategories.map(c => (
              <option key={c} value={c}>{CATEGORIES[c]?.icon} {c}</option>
            ))}
          </select>
          <select className="select" style={{ width: 140 }} value={filters.month} onChange={e => dispatch({ type: 'SET_FILTER', payload: { month: e.target.value } })}>
            <option value="">All Months</option>
            {allMonths.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
          {(filters.search || filters.type || filters.category || filters.month) && (
            <button className="btn btn-ghost" style={{ fontSize: 13 }} onClick={() => dispatch({ type: 'CLEAR_FILTERS' })}>✕ Clear</button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="card" style={{ overflow: 'hidden' }}>
        {filtered.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">🔍</div>
            <p>No transactions match your filters</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="tx-table">
              <thead>
                <tr>
                  <th>Transaction</th>
                  <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('date')}>Date <SortIcon col="date" /></th>
                  <th>Category</th>
                  <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('amount')}>Amount <SortIcon col="amount" /></th>
                  <th>Type</th>
                  {isAdmin && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {filtered.map(t => {
                  const cat = CATEGORIES[t.category] || { icon: '📦', color: '#888' };
                  return (
                    <tr key={t.id}>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                          <div className="tx-cat-icon" style={{ background: cat.color + '22' }}>{cat.icon}</div>
                          <span style={{ color: 'var(--text-1)', fontWeight: 500 }}>{t.description}</span>
                        </div>
                      </td>
                      <td>{new Date(t.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                      <td>
                        <span style={{ fontSize: 13, color: cat.color }}>{cat.icon} {t.category}</span>
                      </td>
                      <td className={t.type === 'income' ? 'amount-income' : 'amount-expense'}>
                        {t.type === 'income' ? '+' : '-'}{fmt(t.amount)}
                      </td>
                      <td>
                        <span className={`badge badge-${t.type}`}>
                          {t.type === 'income' ? '↑' : '↓'} {t.type}
                        </span>
                      </td>
                      {isAdmin && (
                        <td>
                          <div style={{ display: 'flex', gap: 6 }}>
                            <button className="btn btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }}
                              onClick={() => { setEditTx(t); setShowModal(true); }}>✏️</button>
                            <button className="btn btn-danger" style={{ padding: '5px 10px', fontSize: 12 }}
                              onClick={() => confirmDelete(t.id)}>🗑️</button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && <TransactionModal tx={editTx} onClose={() => setShowModal(false)} />}

      {/* Delete confirm */}
      {deleteId && (
        <div className="modal-overlay" onClick={() => setDeleteId(null)}>
          <div className="modal-box" style={{ maxWidth: 360 }} onClick={e => e.stopPropagation()}>
            <div className="modal-title">🗑️ Delete Transaction?</div>
            <p style={{ color: 'var(--text-2)', marginBottom: 20, fontSize: 14 }}>
              This action cannot be undone.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button className="btn btn-ghost" onClick={() => setDeleteId(null)}>Cancel</button>
              <button className="btn btn-danger" onClick={doDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
