import React, { useState, useEffect } from 'react';
import { CATEGORIES } from '../../data/mockData';
import { useApp } from '../../context/AppContext';

const EMPTY = { date: '', description: '', category: 'Food', type: 'expense', amount: '' };

export default function TransactionModal({ tx, onClose }) {
  const { dispatch } = useApp();
  const [form, setForm] = useState(EMPTY);

  useEffect(() => {
    if (tx) setForm({ ...tx, amount: String(tx.amount) });
    else setForm({ ...EMPTY, date: new Date().toISOString().split('T')[0] });
  }, [tx]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const payload = { ...form, amount: parseFloat(form.amount) };
    dispatch({ type: tx ? 'EDIT_TRANSACTION' : 'ADD_TRANSACTION', payload });
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal-box">
        <div className="modal-title">
          {tx ? '✏️ Edit Transaction' : '➕ Add Transaction'}
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
            <div>
              <label className="form-label">Date</label>
              <input className="input" type="date" value={form.date} onChange={e => set('date', e.target.value)} required />
            </div>
            <div>
              <label className="form-label">Amount (₹)</label>
              <input className="input" type="number" min="1" step="0.01" placeholder="0.00" value={form.amount} onChange={e => set('amount', e.target.value)} required />
            </div>
          </div>

          <div style={{ marginBottom: 12 }}>
            <label className="form-label">Description</label>
            <input className="input" placeholder="What was this for?" value={form.description} onChange={e => set('description', e.target.value)} required />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
            <div>
              <label className="form-label">Category</label>
              <select className="select" value={form.category} onChange={e => set('category', e.target.value)}>
                {Object.entries(CATEGORIES).map(([k, v]) => (
                  <option key={k} value={k}>{v.icon} {k}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="form-label">Type</label>
              <select className="select" value={form.type} onChange={e => set('type', e.target.value)}>
                <option value="expense">📉 Expense</option>
                <option value="income">📈 Income</option>
              </select>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
            <button type="button" className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary">{tx ? 'Save Changes' : 'Add Transaction'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
