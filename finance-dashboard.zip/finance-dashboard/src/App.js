import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import AuthPage from './components/auth/LoginPage';
import Sidebar from './components/layout/Sidebar';
import DashboardPage from './components/dashboard/DashboardPage';
import TransactionsPage from './components/transactions/TransactionsPage';
import InsightsPage from './components/insights/InsightsPage';

function AppShell() {
  const { state, dispatch } = useApp();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!state.user) {
    return (
      <>
        <div className="animated-bg"><div className="bg-grid" /><div className="bg-orb3" /></div>
        <AuthPage />
      </>
    );
  }

  const renderPage = () => {
    switch (state.activeTab) {
      case 'dashboard':    return <DashboardPage />;
      case 'transactions': return <TransactionsPage />;
      case 'insights':     return <InsightsPage transactions={state.transactions} />;
      default:             return <DashboardPage />;
    }
  };

  return (
    <>
      <div className="animated-bg"><div className="bg-grid" /><div className="bg-orb3" /></div>
      <div className="app-shell">
        {sidebarOpen && <div className="sidebar-overlay" onClick={() => setSidebarOpen(false)} />}
        <Sidebar onClose={() => setSidebarOpen(false)} />
        <main className="main-content">
          <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:20 }}>
            <button className="hamburger" onClick={() => setSidebarOpen(!sidebarOpen)}>☰</button>
            {/* Role demo switcher */}
            <div
              className="role-switcher"
              onClick={() => dispatch({ type:'SET_ROLE', payload: state.role==='admin'?'viewer':'admin' })}
              title="Toggle role for demo"
              style={{ marginLeft:'auto' }}>
              {state.role==='admin' ? '🔐 Admin' : '👁️ Viewer'}
              <span style={{ color:'var(--accent)', fontSize:11 }}>⇄ switch</span>
            </div>
          </div>
          {renderPage()}
        </main>
      </div>
    </>
  );
}

export default function App() {
  return <AppProvider><AppShell /></AppProvider>;
}
