import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { INITIAL_TRANSACTIONS, generateNewId } from '../data/mockData';

const AppContext = createContext(null);
const STORAGE_KEY = 'financeflow_state';
const USERS_KEY   = 'financeflow_users';

const SEED_USERS = [
  { id: 'u1', name: 'Arjun Sharma', email: 'admin@financeflow.io',  password: 'admin123',  role: 'admin',  avatar: 'AS', joined: '2025-01-01' },
  { id: 'u2', name: 'Priya Nair',   email: 'viewer@financeflow.io', password: 'viewer123', role: 'viewer', avatar: 'PN', joined: '2025-02-10' },
];

const loadUsers = () => { try { const s = localStorage.getItem(USERS_KEY); return s ? JSON.parse(s) : SEED_USERS; } catch { return SEED_USERS; } };
const saveUsers = (u) => { try { localStorage.setItem(USERS_KEY, JSON.stringify(u)); } catch {} };
const loadState = () => { try { const s = localStorage.getItem(STORAGE_KEY); return s ? JSON.parse(s) : null; } catch { return null; } };

const initialState = loadState() || {
  user: null, role: null,
  transactions: INITIAL_TRANSACTIONS,
  filters: { search: '', category: '', type: '', month: '' },
  activeTab: 'dashboard',
};

function reducer(state, action) {
  switch (action.type) {
    case 'LOGIN':        return { ...state, user: action.payload.user, role: action.payload.role, activeTab: 'dashboard' };
    case 'LOGOUT':       return { ...state, user: null, role: null };
    case 'SET_ROLE':     return { ...state, role: action.payload };
    case 'SET_TAB':      return { ...state, activeTab: action.payload };
    case 'SET_FILTER':   return { ...state, filters: { ...state.filters, ...action.payload } };
    case 'CLEAR_FILTERS':return { ...state, filters: { search: '', category: '', type: '', month: '' } };
    case 'ADD_TRANSACTION':  return { ...state, transactions: [{ ...action.payload, id: generateNewId() }, ...state.transactions] };
    case 'EDIT_TRANSACTION': return { ...state, transactions: state.transactions.map(t => t.id === action.payload.id ? action.payload : t) };
    case 'DELETE_TRANSACTION': return { ...state, transactions: state.transactions.filter(t => t.id !== action.payload) };
    case 'UPDATE_PROFILE': return { ...state, user: { ...state.user, ...action.payload } };
    default: return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch]    = useReducer(reducer, initialState);
  const [users, setUsersRaw] = React.useState(loadUsers);
  const [authError, setAuthError] = React.useState('');

  const setUsers = (u) => { setUsersRaw(u); saveUsers(u); };

  useEffect(() => { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {} }, [state]);

  const login = (email, password) => {
    setAuthError('');
    const found = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!found) { setAuthError('Invalid email or password.'); return false; }
    dispatch({ type: 'LOGIN', payload: { user: { id: found.id, name: found.name, avatar: found.avatar, email: found.email, joined: found.joined }, role: found.role } });
    return true;
  };

  const signup = (name, email, password, role) => {
    setAuthError('');
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) { setAuthError('An account with this email already exists.'); return false; }
    const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
    const newUser  = { id: generateNewId(), name, email, password, role, avatar: initials, joined: new Date().toISOString().split('T')[0] };
    setUsers([...users, newUser]);
    dispatch({ type: 'LOGIN', payload: { user: { id: newUser.id, name, avatar: initials, email, joined: newUser.joined }, role } });
    return true;
  };

  const logout = () => dispatch({ type: 'LOGOUT' });

  return (
    <AppContext.Provider value={{ state, dispatch, users, login, signup, logout, authError, setAuthError }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
