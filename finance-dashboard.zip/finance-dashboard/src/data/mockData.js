export const CATEGORIES = {
  Food:        { icon: '🍔', color: '#f472b6' },
  Transport:   { icon: '🚗', color: '#818cf8' },
  Shopping:    { icon: '🛍️', color: '#fb923c' },
  Health:      { icon: '💊', color: '#34d399' },
  Salary:      { icon: '💼', color: '#6ee7b7' },
  Investment:  { icon: '📈', color: '#fbbf24' },
  Utilities:   { icon: '💡', color: '#60a5fa' },
  Entertainment:{ icon: '🎬', color: '#c084fc' },
  Freelance:   { icon: '💻', color: '#a3e635' },
  Rent:        { icon: '🏠', color: '#fb7185' },
};

let txIdCounter = 100;
const uid = () => String(++txIdCounter);

export const INITIAL_TRANSACTIONS = [
  { id: uid(), date: '2025-06-01', description: 'Monthly Salary', category: 'Salary',   type: 'income',  amount: 85000 },
  { id: uid(), date: '2025-06-02', description: 'Grocery Store', category: 'Food',      type: 'expense', amount: 3200  },
  { id: uid(), date: '2025-06-03', description: 'Uber Ride',     category: 'Transport', type: 'expense', amount: 450   },
  { id: uid(), date: '2025-06-04', description: 'Netflix',       category: 'Entertainment', type: 'expense', amount: 649 },
  { id: uid(), date: '2025-06-05', description: 'Freelance Project', category: 'Freelance', type: 'income', amount: 18000 },
  { id: uid(), date: '2025-06-06', description: 'Amazon Order',  category: 'Shopping',  type: 'expense', amount: 2800  },
  { id: uid(), date: '2025-06-07', description: 'Electricity Bill', category: 'Utilities', type: 'expense', amount: 1200 },
  { id: uid(), date: '2025-06-08', description: 'Pharmacy',      category: 'Health',    type: 'expense', amount: 890   },
  { id: uid(), date: '2025-06-09', description: 'Investment SIP', category: 'Investment', type: 'expense', amount: 5000 },
  { id: uid(), date: '2025-06-10', description: 'Restaurant Dinner', category: 'Food',  type: 'expense', amount: 1800  },
  { id: uid(), date: '2025-06-12', description: 'Rent Payment',  category: 'Rent',      type: 'expense', amount: 18000 },
  { id: uid(), date: '2025-06-14', description: 'Gym Membership', category: 'Health',   type: 'expense', amount: 1499  },
  { id: uid(), date: '2025-06-15', description: 'Consulting Fee', category: 'Freelance', type: 'income', amount: 12000 },
  { id: uid(), date: '2025-06-17', description: 'Clothing Store', category: 'Shopping', type: 'expense', amount: 3600  },
  { id: uid(), date: '2025-06-19', description: 'Spotify',       category: 'Entertainment', type: 'expense', amount: 119 },
  { id: uid(), date: '2025-06-20', description: 'Metro Card',    category: 'Transport', type: 'expense', amount: 500   },
  { id: uid(), date: '2025-06-22', description: 'Dividend Income', category: 'Investment', type: 'income', amount: 3200 },
  { id: uid(), date: '2025-06-24', description: 'Internet Bill', category: 'Utilities', type: 'expense', amount: 799   },
  { id: uid(), date: '2025-06-25', description: 'Zomato Order',  category: 'Food',      type: 'expense', amount: 650   },
  { id: uid(), date: '2025-06-28', description: 'Movie Tickets', category: 'Entertainment', type: 'expense', amount: 800 },

  { id: uid(), date: '2025-05-01', description: 'Monthly Salary', category: 'Salary',  type: 'income',  amount: 85000 },
  { id: uid(), date: '2025-05-03', description: 'Grocery Store', category: 'Food',     type: 'expense', amount: 2800  },
  { id: uid(), date: '2025-05-06', description: 'Freelance Project', category: 'Freelance', type: 'income', amount: 9000 },
  { id: uid(), date: '2025-05-10', description: 'Amazon Order',  category: 'Shopping', type: 'expense', amount: 4200  },
  { id: uid(), date: '2025-05-12', description: 'Rent Payment',  category: 'Rent',     type: 'expense', amount: 18000 },
  { id: uid(), date: '2025-05-15', description: 'Electricity Bill', category: 'Utilities', type: 'expense', amount: 1100 },
  { id: uid(), date: '2025-05-20', description: 'Restaurant',    category: 'Food',     type: 'expense', amount: 2100  },
  { id: uid(), date: '2025-05-25', description: 'Investment SIP', category: 'Investment', type: 'expense', amount: 5000 },

  { id: uid(), date: '2025-04-01', description: 'Monthly Salary', category: 'Salary',  type: 'income',  amount: 85000 },
  { id: uid(), date: '2025-04-05', description: 'Grocery Store', category: 'Food',     type: 'expense', amount: 3100  },
  { id: uid(), date: '2025-04-08', description: 'Freelance',     category: 'Freelance', type: 'income', amount: 7500  },
  { id: uid(), date: '2025-04-12', description: 'Rent Payment',  category: 'Rent',     type: 'expense', amount: 18000 },
  { id: uid(), date: '2025-04-16', description: 'Shopping Mall', category: 'Shopping', type: 'expense', amount: 5200  },
  { id: uid(), date: '2025-04-22', description: 'Electricity',   category: 'Utilities', type: 'expense', amount: 980  },
  { id: uid(), date: '2025-04-28', description: 'Investment SIP', category: 'Investment', type: 'expense', amount: 5000 },
];

export const generateNewId = () => String(Date.now());

export const fmt = (n) =>
  '₹' + Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });

export const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export const getMonthlyData = (transactions) => {
  const map = {};
  transactions.forEach(t => {
    const d = new Date(t.date);
    const key = `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
    if (!map[key]) map[key] = { name: MONTHS[d.getMonth()], income: 0, expenses: 0 };
    if (t.type === 'income')  map[key].income   += t.amount;
    if (t.type === 'expense') map[key].expenses += t.amount;
  });
  return Object.values(map).slice(-6);
};

export const getCategoryData = (transactions) => {
  const map = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    map[t.category] = (map[t.category] || 0) + t.amount;
  });
  return Object.entries(map)
    .map(([name, value]) => ({ name, value, icon: CATEGORIES[name]?.icon || '📦', color: CATEGORIES[name]?.color || '#888' }))
    .sort((a,b) => b.value - a.value);
};
