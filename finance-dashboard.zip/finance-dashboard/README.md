# 💰 FinanceFlow Dashboard

A clean, interactive personal finance dashboard built with React.

## 🚀 Quick Start

```bash
cd finance-dashboard
npm install
npm start
```
Opens at **http://localhost:3000**

---

## 🔐 Demo Login

| Role   | Password    | Access                        |
|--------|-------------|-------------------------------|
| Admin  | `admin123`  | View + Add + Edit + Delete    |
| Viewer | `viewer123` | View only                     |

Or click the **Quick Demo** buttons on the login screen.

---

## 📁 Project Structure

```
src/
├── components/
│   ├── auth/
│   │   └── LoginPage.js          # Login with role selection
│   ├── dashboard/
│   │   ├── DashboardPage.js      # Overview with summary + recent
│   │   ├── SummaryCards.js       # Balance, income, expense, savings cards
│   │   └── Charts.js             # Area chart + Pie chart
│   ├── transactions/
│   │   ├── TransactionsPage.js   # Filter/search/sort table
│   │   └── TransactionModal.js   # Add/Edit modal
│   ├── insights/
│   │   └── InsightsPage.js       # Smart insights + bar charts
│   └── layout/
│       └── Sidebar.js            # Navigation sidebar
├── context/
│   └── AppContext.js             # Global state (useReducer + localStorage)
├── data/
│   └── mockData.js               # Mock transactions + helper functions
└── styles/
    └── global.css                # All styles, animations, responsive
```

---

## ✨ Features

### Dashboard
- Summary cards: Total Balance, Income, Expenses, Savings Rate
- Area chart: Income vs Expenses trend (last 6 months)
- Pie chart: Spending breakdown by category
- Recent 5 transactions

### Transactions
- Full list with icons per category
- Filter by: search, type, category, month
- Sort by: date, amount
- Admin: Add / Edit / Delete transactions
- Export to CSV

### Insights
- Top spending category
- Net savings & savings rate
- Month-over-month expense change
- Average transaction amount
- Financial health score
- Category bar chart + Monthly comparison bar chart

### Role-Based UI
- **Admin**: Full CRUD on transactions
- **Viewer**: Read-only, no add/edit/delete buttons
- Toggle roles via the top-right role switcher (demo)

---

## 🎨 Design Highlights
- Dark mode with animated gradient orbs + grid background
- Syne (display) + DM Sans (body) fonts
- Fully responsive: mobile sidebar drawer, stacked grids on small screens
- LocalStorage persistence across sessions
- Smooth CSS animations and transitions
